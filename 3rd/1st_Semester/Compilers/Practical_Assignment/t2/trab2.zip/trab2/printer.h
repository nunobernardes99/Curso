#include "code1.h"

void printInstr(Instr *i);

void printListInstr(listaInstr *l1);

void printVar(Var *variavel, char *reg);

void printLabel(Label *lab, char *reg);

void printCondi(Instr *i);