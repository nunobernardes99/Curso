int main() {
    int a = 2 + 3 * 5;
    return 1;
}