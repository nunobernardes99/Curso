#include <stdlib.h>
#include <stdio.h>
#include "code1.h"
#include "ast.h"
#include "parser.h"

listaInstr* compileExpr(Expr* expr);

Instr* mkInstrI(IKind kind, int n) {
    Instr* instr = (Instr*) malloc(sizeof(Instr));
    instr->kind=kind;
    instr->args.num=n;
    return instr;
}
Instr* mkInstrC(IKind kind, char* c) {
    Instr* instr = (Instr*) malloc(sizeof(Instr));
    instr->kind=kind;
    instr->args.var=c;
    return instr;
}
listaInstr* mkList(Instr* instr, listaInstr* l1) {
    listaInstr* l = (listaInstr*) malloc(sizeof(listaInstr));
    l->head=instr;
    l->tail=l1;
    return l;
}
Instr* head(listaInstr* l1) {
    return l1->head;
}
listaInstr* tail(listaInstr* l1) {
    return l1->tail;
}
listaInstr* append(listaInstr* l1, listaInstr* l2) {
    if(l1 == NULL) {
        return l2;
    }
    return mkList(head(l1), append(tail(l1), l2));
}

listaInstr* compileExpr(Expr* e) {
    listaInstr* l1 = (listaInstr*) malloc(sizeof(listaInstr));
    switch(e->kind) {
        case E_INTEGER:
            l1 = mkList(mkInstrI(NUMI, e->attr.value), NULL);
        break;
        case E_VAR:
            l1 = mkList(mkInstrC(VARI, e->attr.var), NULL);        
        break;
        case E_OPERATION:
            l1 = append(compileExpr(e->attr.op.left), compileExpr(e->attr.op.right));
            switch (e->attr.op.operator) {
                case PLUS:
                    l1 = append(l1, mkList(mkInstrI(ADI, 0), NULL));
                break;
                case SUB:
                    l1 = append(l1, mkList(mkInstrI(SBI, 0), NULL));
                break;
                case MUL:
                    l1 = append(l1, mkList(mkInstrI(MTI, 0), NULL));
                break;
                case DIV:
                    l1 = append(l1, mkList(mkInstrI(DVI, 0), NULL));
                break;
                case MOD:
                    l1 = append(l1, mkList(mkInstrI(MDI, 0), NULL));
                break;
            }
    }
    return l1;
}

void printInstr(Instr* instr) {
    switch (instr->kind) {
        case NUMI:
            printf("NUMBER %d\n", instr->args.num);
        break;
        case VARI:
            printf("VAR %s", instr->args.var);
        break;
        case ADI:
            printf("ADI\n");
        break;
        case SBI:
            printf("SBI\n");
        break;
        case DVI:
            printf("DVI\n");
        break;
        case MTI:
            printf("MTI\n");
        break;
        case MDI:
            printf("MDI\n");
        break;
    }
}

void printListInstr(listaInstr* l1) {
    printInstr(l1->head);
    if(l1->tail != NULL) {
        printInstr(l1->tail->head);
    }
}

int main(int argc, char** argv) {
  --argc;++argv;
  if(argc!=0) {
    yyin=fopen(*argv,"r");
    if(!yyin){
      printf("'%s':could not open file\n", *argv);
      return 1;
    }
  }
  if(yyparse()==0){
    listaInstr* l = compileExpr( (Expr*) root);
    printListInstr(l); //numa proxima fase este print vai gerar mips
    printf("SYSCALL\n");

  }
  return 0;
}