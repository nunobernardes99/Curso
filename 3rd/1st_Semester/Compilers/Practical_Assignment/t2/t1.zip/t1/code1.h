typedef enum {
    NUMI, VARI, ADI, SBI, DVI, MTI, MDI
} IKind;

typedef struct _li listaInstr;
typedef struct _Instr Instr;
struct _Instr {
    IKind kind;
    union {
        char* var;
        int num;
    } args;
};

struct _li {
    Instr* head;
    struct _li* tail;
};

Instr* mkInstrI(IKind kind, int n); //for numbers
Instr* mkInstrC(IKind kind, char *c); // for chars like t1, t2, etc...
Instr* head(listaInstr* l1); // head of list
listaInstr* tail(listaInstr* l1); //tail of list
listaInstr* append(listaInstr* l1, listaInstr* l2); //append l2 to l1
listaInstr* mkList(Instr* instr, listaInstr* l1);