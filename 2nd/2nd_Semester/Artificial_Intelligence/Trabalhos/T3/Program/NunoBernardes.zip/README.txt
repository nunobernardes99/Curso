Alunos:
    João Paulo Monteiro
    Nuno José Moreira Bernardes

Ficheiros:
    Decision.java
    No.java
    Exemplos.java
    Atributos.java

Ficheiros teste:
    restaurant.csv
    iris.csv
    weather.csv

Para compilar e executar:
    1) Aceder à pasta onde se encontram todos os ficheiros java.
    2) Correr o comando "javac Decision.java && java Decision".
    3) Selecionando a primeira opção, escrever qual o ficheiro CSV que pretende executar

NOTA IMPORTANTE: Para o programa funcionar, a primeira coluna tem de ter o ID do exemplo, senão não irá analisar o programa.

O que está em falta:
    - Criar grupos de intervalos para criar árvores menos extensas (caso do ficheiro iris.csv).
    - Código mais limpo e com menos repetições.