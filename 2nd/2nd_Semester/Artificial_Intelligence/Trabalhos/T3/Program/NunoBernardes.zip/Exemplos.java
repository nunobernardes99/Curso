import java.util.*;
import java.lang.*;
public class Exemplos {
    LinkedList<String> exsList;
    int index;
    
    Exemplos() {
        exsList = new LinkedList<String>();
    }
}